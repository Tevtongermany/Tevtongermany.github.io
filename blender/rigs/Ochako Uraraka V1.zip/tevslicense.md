### Tevtongermany's Cool Rig license 
1. You can use my rigs and stuff for what ever you want I do not care but it would be nice if you would give me credit
2. Hamburger
3. do NOT claim that the rig is made by you!!! >:(